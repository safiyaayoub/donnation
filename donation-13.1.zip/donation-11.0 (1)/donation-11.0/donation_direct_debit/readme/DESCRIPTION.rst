With this module, when you validate a donation that has a payment method linked to a SEPA direct debit payment mode :

* if a draft direct debit order for SEPA Direct Debit already exists, a new payment line is added to it for that donation,

* otherwise, a new SEPA direct debit order is created for this donation.
