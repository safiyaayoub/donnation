Validate the donations as usual !
