In the menu *Accounting > Configuration > Miscellaneous > Payment Mode*, make sure that you have a payment mode for SEPA Direct Debit that is linked to an Account Journal allowed for donations.
