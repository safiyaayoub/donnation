To configure the module, you have to create a bank journal dedicated
to donations via credit transfer, that will have a special transfer
account as default debit/credit account.

Then, in the menu *Accounting > Configuration > Settings*, in the
section *Donations*, you must select this journal as the *Donations via
Credit Transfer Journal*. You must also select the donation product that
will be used by default on donation generated from bank statements.
