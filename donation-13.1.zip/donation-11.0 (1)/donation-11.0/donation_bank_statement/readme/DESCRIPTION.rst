This module is designed to handle donation received by credit transfer.
After the import of the bank statement, you can start a wizard that will
create a donation for each unreconciled bank statement lines affected to
a particular account.
